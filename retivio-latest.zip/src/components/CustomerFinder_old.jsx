import React, { useEffect, useState } from "react";
import { Country } from "country-state-city";
import { searchBusinesses } from "../services/customerFinderService";

function CustomerFinder() {
  const [keyword, setKeyword] = useState("");

  const [country, setCountry] = useState("IN");
  const [countries, setCountries] = useState([]);

  const [location, setLocation] = useState("");
  const [pincode, setPincode] = useState("");

  const [category, setCategory] = useState("Salon");
  const [radius, setRadius] = useState(2000);

  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState([]);
  const [error, setError] = useState("");

  const [currentLocationLoading, setCurrentLocationLoading] =
    useState(false);

  const [currentPage, setCurrentPage] = useState(1);

  const pageSize = 10;

  useEffect(() => {
    setCountries(
      Country.getAllCountries().sort((a, b) =>
        a.name.localeCompare(b.name)
      )
    );
  }, []);

  const handleCurrentLocation = () => {
    if (!navigator.geolocation) {
      setError("Location is not supported.");
      return;
    }

    setCurrentLocationLoading(true);

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        try {
          const { latitude, longitude } = position.coords;

          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${latitude}&lon=${longitude}`
          );

          const data = await response.json();

          setCountry(
            data.address?.country_code?.toUpperCase() || "IN"
          );

          setLocation(
            data.address?.city ||
            data.address?.town ||
            data.address?.village ||
            ""
          );

          setPincode(data.address?.postcode || "");

        } catch {
          setError("Unable to detect location.");
        } finally {
          setCurrentLocationLoading(false);
        }
      },
      () => {
        setCurrentLocationLoading(false);
        setError("Location permission denied.");
      }
    );
  };

  const handleSearch = async () => {
    if (!location.trim()) {
      setError("Please enter city.");
      return;
    }

    setLoading(true);
    setError("");

    try {
      const data = await searchBusinesses({
        keyword: keyword || category,
        location,
        category,
        radius,
      });

      setResults(data.businesses || []);
      setCurrentPage(1);

    } catch (err) {
      setError(err.message);
      setResults([]);
    } finally {
      setLoading(false);
    }
  };

  const totalPages = Math.ceil(results.length / pageSize);

  const paginatedResults = results.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );

  const phoneCount = results.filter(
    (b) => b.phone
  ).length;

  const websiteCount = results.filter(
    (b) => b.website
  ).length;

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-purple-700 via-violet-600 to-indigo-600 rounded-3xl p-6 text-white shadow-xl">

        <h1 className="text-3xl font-bold">
          🚀 Customer Finder
        </h1>

        <p className="mt-3 text-purple-100 max-w-2xl">
          Discover nearby business opportunities to grow your salon.
        </p>

      </div>

      <div className="bg-white rounded-2xl shadow border p-6">

        <h2 className="text-xl font-bold mb-5">
          Search Nearby Businesses
        </h2>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-600 rounded-xl p-3 mb-4">
            {error}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">

          <input
            type="text"
            placeholder="Keyword"
            value={keyword}
            onChange={(e) => setKeyword(e.target.value)}
            className="border rounded-xl px-4 py-3"
          />

          <select
            value={country}
            onChange={(e) => setCountry(e.target.value)}
            className="border rounded-xl px-4 py-3"
          >
            {countries.map((c) => (
              <option key={c.isoCode} value={c.isoCode}>
                {c.flag} {c.name}
              </option>
            ))}
          </select>

          <input
            type="text"
            placeholder="City"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            className="border rounded-xl px-4 py-3"
          />

          <input
            type="text"
            placeholder="Pincode (Optional)"
            value={pincode}
            onChange={(e) => setPincode(e.target.value)}
            className="border rounded-xl px-4 py-3"
          />

          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="border rounded-xl px-4 py-3"
          >
            <option>Salon</option>
            <option>Spa</option>
            <option>Barber</option>
            <option>Beauty Parlour</option>
            <option>Hair Studio</option>
            <option>Nail Studio</option>
            <option>Gym</option>
            <option>Hotel</option>
            <option>Cafe</option>
            <option>Restaurant</option>
            <option>Boutique</option>
          </select>

          <select
            value={radius}
            onChange={(e) => setRadius(Number(e.target.value))}
            className="border rounded-xl px-4 py-3"
          >
            <option value={500}>500 m</option>
            <option value={1000}>1 km</option>
            <option value={2000}>2 km</option>
            <option value={5000}>5 km</option>
            <option value={10000}>10 km</option>
          </select>

        </div>

        <div className="flex flex-wrap gap-3 mt-5">

          <button
            onClick={handleCurrentLocation}
            className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-3 rounded-xl font-semibold"
          >
            {currentLocationLoading
              ? "Detecting..."
              : "📍 Use Current Location"}
               {results.length > 0 && (

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">

          <div className="bg-white rounded-xl shadow border p-4">
            <p className="text-sm text-gray-500">
              Businesses
            </p>

            <h2 className="text-3xl font-bold mt-2">
              {results.length}
            </h2>
          </div>

          <div className="bg-white rounded-xl shadow border p-4">
            <p className="text-sm text-gray-500">
              Phone
            </p>

            <h2 className="text-3xl font-bold mt-2">
              {phoneCount}
            </h2>
          </div>

          <div className="bg-white rounded-xl shadow border p-4">
            <p className="text-sm text-gray-500">
              Website
            </p>

            <h2 className="text-3xl font-bold mt-2">
              {websiteCount}
            </h2>
          </div>

          <div className="bg-white rounded-xl shadow border p-4">
            <p className="text-sm text-gray-500">
              Pages
            </p>

            <h2 className="text-3xl font-bold mt-2">
              {currentPage} / {totalPages || 1}
            </h2>
          </div>

        </div>

      )}

      {results.length === 0 ? (

        <div className="bg-white rounded-2xl shadow border p-12 text-center mt-6">

          <div className="text-6xl">
            📍
          </div>

          <h3 className="text-2xl font-bold mt-5">
            Ready to Discover Opportunities
          </h3>

          <p className="text-gray-500 mt-3">
            Search nearby businesses and save potential leads directly into Retivio.
          </p>

        </div>

      ) : (

        <div className="space-y-4 mt-6">

          {paginatedResults.map((business) => (

            <div
              key={business.id}
              className="bg-white rounded-2xl shadow border p-5"
            >

              <div className="flex justify-between items-start">

                <div>

                  <h3 className="text-xl font-bold">
                    {business.name}
                  </h3>

                  <p className="text-gray-500 mt-1">
                    {business.category}
                  </p>

                  {business.address && (

                    <p className="text-sm text-gray-500 mt-2">
                      📍 {business.address}
                    </p>

                  )}

                </div>

                <span className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-xs font-semibold">
                  Lead
                </span>

              </div>

              <div className="flex flex-wrap gap-3 mt-5">

                {business.phone && (

                  <a
                    href={`tel:${business.phone}`}
                    className="bg-green-600 text-white px-4 py-2 rounded-lg"
                  >
                    📞 Call
                  </a>

                )}

                {business.phone && (

                  <a
                    href={`https://wa.me/${business.phone}`}
                    target="_blank"
                    rel="noreferrer"
                    className="bg-emerald-500 text-white px-4 py-2 rounded-lg"
                  >
                    💬 WhatsApp
                  </a>

                )}

                <a
                  href={`https://maps.google.com/?q=${
          <div className="flex justify-center items-center gap-4 mt-8">

            <button
              disabled={currentPage === 1}
              onClick={() => setCurrentPage((p) => p - 1)}
              className="px-4 py-2 rounded-lg bg-gray-200 disabled:opacity-40"
            >
              ⬅ Previous
            </button>

            <span className="font-medium">
              Page {currentPage} of {totalPages || 1}
            </span>

            <button
              disabled={currentPage === totalPages}
              onClick={() => setCurrentPage((p) => p + 1)}
              className="px-4 py-2 rounded-lg bg-purple-700 text-white disabled:opacity-40"
            >
              Next ➡
            </button>

          </div>

        </div>

      )}

    </div>
  );
}

export default CustomerFinder;o

