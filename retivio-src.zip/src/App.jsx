import React, { useState, useEffect } from "react";
import Header from "./components/Header";
import Sidebar from "./components/Sidebar";
import CustomerTable from "./components/CustomerTable";
import AnalyticsSummary from "./components/AnalyticsSummary";
import ActionButtons from "./components/ActionButtons";
import NewCustomerForm from "./components/NewCustomerForm";
import VisitEntry from "./components/VisitEntry";
import SearchBar from "./components/SearchBar";
import ActionRequired from "./components/ActionRequired";
import QuickActions from "./components/QuickActions";
import RecentActivity from "./components/RecentActivity";
import GrowthSnapshot from "./components/GrowthSnapshot";
import TopCustomers from "./components/TopCustomers";
import CampaignPerformance from "./components/CampaignPerformance";
import RevenueTrend from "./components/RevenueTrend";
import AIRecommendations from "./components/AIRecommendations";
import { supabase } from "./lib/supabase";
import { Routes, Route, Navigate } from "react-router-dom";
import Login from "./pages/Login";
import Signup from "./pages/Signup";


function App() {
const [customers, setCustomers] = useState([]);  
  const [search, setSearch] = useState("");
const [sidebarOpen, setSidebarOpen] = useState(false);
const [activePage, setActivePage] = useState("dashboard");
const [session, setSession] = useState(null);
const [loading, setLoading] = useState(true);

const fetchCustomers = async () => {
const {
  data: { user },
} = await supabase.auth.getUser();
if (!user) {
  setCustomers([]);
  return;
}

const { data, error } = await supabase
  .from("customers")
  .select("*")
  .eq("user_id", user.id);

  if (error) {
    console.log(error);
    return;
  }

const formatted = data.map((c) => ({
  id: c.id,
  name: c.name,
  phone: c.phone,
  service: c.service,
  lastVisit: c.last_visit,
  nextDue: c.next_due,
  visits: c.visits,
  totalSpend: c.total_spend,
  loyalty: c.loyalty,
  status: c.status,
}));
  setCustomers(formatted);
};
useEffect(() => {
  fetchCustomers();
}, []);
useEffect(() => {
  supabase.auth.getSession().then(({ data: { session } }) => {
    setSession(session);
    setLoading(false);
  });

  const {
    data: { subscription },
  } = supabase.auth.onAuthStateChange((_event, session) => {
    setSession(session);
    setLoading(false);
  });

  return () => subscription.unsubscribe();
}, []);
  const filteredCustomers = customers.filter(
    (customer) =>
      customer.name
        .toLowerCase()
        .includes(search.toLowerCase()) ||
      customer.phone.includes(search)
  );
if (loading) {
  return <div>Loading...</div>;
}


 return (
  <Routes>
    <Route path="/login" element={<Login />} />
    <Route path="/signup" element={<Signup />} />
<Route
  path="/"
  element={(
    <>
<div className="min-h-screen flex bg-gray-100">

{sidebarOpen && (
  <>
    <div
      className="fixed inset-0 bg-black/40 z-40"
      onClick={() => setSidebarOpen(false)}
    />

    <Sidebar
      setSidebarOpen={setSidebarOpen}
      activePage={activePage}
      setActivePage={setActivePage}
    />
  </>
)}

<div className="flex-1 overflow-x-hidden">
        <Header setSidebarOpen={setSidebarOpen} />
<div className="p-3 md:p-6">
          <h1 className="text-2xl md:text-4xl font-bold">
  Dashboard
</h1>

<p className="text-gray-500 mt-1">
  Welcome back! Here's what's happening today.
</p>

          <p className="mt-4">
            Welcome back!
          </p>

{activePage === "dashboard" && (
  <>
    <AnalyticsSummary customers={customers} />

    <RevenueTrend />

<AIRecommendations customers={customers} />

    <ActionRequired />

    <QuickActions
      setActivePage={setActivePage}
    />

    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">

  <RecentActivity
    customers={customers}
  />

  <TopCustomers
    customers={customers}
  />

  <GrowthSnapshot
    customers={customers}
  />

  <CampaignPerformance />

</div>
  </>
)}
  
{activePage === "customers" && (
  <>
    <SearchBar
      search={search}
      setSearch={setSearch}
    />

    <CustomerTable
      customers={filteredCustomers}
    />
  </>
)}

{activePage === "visit" && (
  <>
    <NewCustomerForm
      customers={customers}
      setCustomers={setCustomers}
    />

    <VisitEntry
      customers={customers}
      setCustomers={setCustomers}
    />
  </>
)}

{activePage === "campaigns" && (
  <ActionButtons />
)}

{activePage === "reports" && (
  <div className="bg-white p-4 rounded shadow">
   
    <p>
      Reports module coming soon...
    </p>
  </div>
)}

{activePage === "settings" && (
  <div className="bg-white p-4 rounded shadow">
    <h2 className="text-xl font-bold">
      Settings
    </h2>

    <p>
      Settings module coming soon...
    </p>
  </div>
)}
        </div>
      </div>
    </div>
</>
  )}
/>

    <Route path="*" element={<Navigate to="/" />} />
  </Routes>
);
}

export default App;
